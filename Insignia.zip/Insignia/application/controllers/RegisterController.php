<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  RegisterController extends CI_Controller {


  public function __construct()
  {
    parent::__construct();
    $this->load->library("form_validation");
  }

  public function index()
  {

    $this->form_validation->set_rules("name","Name","required");
    $this->form_validation->set_rules("email","Email","required|is_unique[users.email]");
    $this->form_validation->set_rules("password","Password","required");
    $this->form_validation->set_rules("confirm","Confirm Password","required|matches[password]");
    $this->form_validation->set_rules("phone","Phone","required");
    if ($this->form_validation->run() !== FALSE) {

      $data = array(
        "name" => $this->input->post("name"),
        "email" => $this->input->post("email"),
        "password" => $this->encrypt($this->input->post("password")),
        "phone" => $this->input->post("phone")
      );
      $this->db->insert("users",$data);
      redirect(base_url("dashboard"));
      $this->session->set_flashdata('success','User was registered');
    }else{
      $this->load->view("account/signup");
    }

  }


  public function encrypt($password)
  {
    $hash = password_hash($password,PASSWORD_BCRYPT);
    return $hash;
  }



}
?>
