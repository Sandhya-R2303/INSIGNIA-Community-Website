<?php $this->load->view("layout/header") ?>
<section >
  <div class="container">
    <?php if (isset($_SESSION['success'])): ?>
      <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
      </div>
    <?php endif; ?>
  </div>
  <div class="container">
    <?php if (isset($_SESSION['error'])): ?>
      <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="container pt-2">
  </br>
</br>
<div class="card p-4 ">
  <div class="row">

    <div class="col-md-6">
      <form action="" method="post">
        <div class="form-group">
          <textarea placeholder="Enter what's in your mind today." name="matter" required class="form-control" ></textarea>
        </div>
        <div class="form-group">
          <button type="submit" name="post_matter" class="btn btn-primary" name="button">Post</button>
        </div>
      </form>
    </div>
  </div>
</div>

</div>
</section>

<section>

  <div class="hi">
    <div class="col-md-6 pl-5">
    </br>
  </br>
  <h4>Matters posted by the users</h4>
  <?php foreach ($post_matter as $post): ?>
    <div class="pt-5 pb-5 ">
      <div class="card p-4 quote">
        <?= $post->matter ?>
      </div>
      <div class="">
        Posted By:<?php echo $post->email ?>
      </div>
      <br>

      <ul  class="list-group" >
    <?php foreach ($comments as $comment): ?>
      <?php if ($comment->post_id == $post->id): ?>
        <li class="list-group-item">
          <?php echo $comment->comment ?>
        </li>
        Answered By:<?php echo $comment->by ?>
      <?php endif; ?>
    <?php endforeach; ?>
  </ul>
    <br>
    <form action="" method="post">
      <label> Answer: <br>
        <textarea name="comment" class="input" required></textarea>
        <input type="hidden" name="post_id" value="<?php echo $post->id ?>">
      </br>
      <button type="submit"  class= "btn btn-primary answer" name="btn_comment">Answer</button>
    </label>
  </form>
  </div>
<?php endforeach; ?>
</div>
</div>
</section>
<?php $this->load->view("layout/footer") ?>
