
<script src="<?php echo base_url("assets/js/jquery.js") ?>" charset="utf-8"></script>
<script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>" charset="utf-8"></script>
<script src="<?php echo base_url("assets/js/bootstrap.bundle.min.js") ?>" charset="utf-8"></script>

</body>
</html>
